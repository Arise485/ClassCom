import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar, Book, Users, Clock } from 'lucide-react';

interface Topic {
  id: string;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  estimatedTime: string;
  assignedTo?: string;
  dueDate?: string;
}

interface Subject {
  name: string;
  code: string;
  topics: Topic[];
}

export function PPTTopicsDashboard() {
  const subjects: Subject[] = [
    {
      name: 'Data Structures',
      code: 'CS301',
      topics: [
        {
          id: '1',
          title: 'Binary Search Trees',
          description: 'Implementation and operations of BST including insertion, deletion, and traversal algorithms.',
          difficulty: 'Medium',
          estimatedTime: '15-20 minutes',
          assignedTo: 'Sarah Wilson',
          dueDate: '2024-01-25'
        },
        {
          id: '2',
          title: 'Hash Tables',
          description: 'Hash functions, collision resolution techniques, and practical applications.',
          difficulty: 'Medium',
          estimatedTime: '12-15 minutes'
        },
        {
          id: '3',
          title: 'Graph Algorithms',
          description: 'BFS, DFS, Dijkstra\'s algorithm, and minimum spanning trees.',
          difficulty: 'Hard',
          estimatedTime: '20-25 minutes'
        },
        {
          id: '4',
          title: 'Dynamic Programming',
          description: 'Principles of DP, memoization, and classic problems like knapsack and LCS.',
          difficulty: 'Hard',
          estimatedTime: '18-22 minutes'
        }
      ]
    },
    {
      name: 'Operating Systems',
      code: 'CS302',
      topics: [
        {
          id: '5',
          title: 'Process Scheduling',
          description: 'CPU scheduling algorithms including FCFS, SJF, Round Robin, and Priority scheduling.',
          difficulty: 'Medium',
          estimatedTime: '15-18 minutes',
          assignedTo: 'Mike Chen',
          dueDate: '2024-01-28'
        },
        {
          id: '6',
          title: 'Memory Management',
          description: 'Virtual memory, paging, segmentation, and memory allocation strategies.',
          difficulty: 'Hard',
          estimatedTime: '20-25 minutes'
        },
        {
          id: '7',
          title: 'File Systems',
          description: 'File system organization, directory structures, and disk scheduling.',
          difficulty: 'Medium',
          estimatedTime: '15-20 minutes'
        },
        {
          id: '8',
          title: 'Deadlocks',
          description: 'Deadlock detection, prevention, avoidance, and recovery strategies.',
          difficulty: 'Medium',
          estimatedTime: '12-15 minutes'
        }
      ]
    },
    {
      name: 'Database Systems',
      code: 'CS303',
      topics: [
        {
          id: '9',
          title: 'SQL Joins',
          description: 'Inner, outer, left, right joins and their practical applications with examples.',
          difficulty: 'Easy',
          estimatedTime: '10-12 minutes',
          assignedTo: 'Emma Davis',
          dueDate: '2024-01-15'
        },
        {
          id: '10',
          title: 'Normalization',
          description: 'Database normalization forms (1NF, 2NF, 3NF, BCNF) and denormalization.',
          difficulty: 'Medium',
          estimatedTime: '15-18 minutes'
        },
        {
          id: '11',
          title: 'Indexing',
          description: 'B-trees, B+ trees, hash indexing, and query optimization.',
          difficulty: 'Hard',
          estimatedTime: '18-22 minutes'
        },
        {
          id: '12',
          title: 'Transactions',
          description: 'ACID properties, transaction isolation levels, and concurrency control.',
          difficulty: 'Hard',
          estimatedTime: '20-25 minutes'
        }
      ]
    },
    {
      name: 'Computer Networks',
      code: 'CS304',
      topics: [
        {
          id: '13',
          title: 'TCP/IP Protocol Stack',
          description: 'Detailed explanation of TCP/IP layers and their functionalities.',
          difficulty: 'Medium',
          estimatedTime: '15-18 minutes'
        },
        {
          id: '14',
          title: 'Routing Algorithms',
          description: 'Distance vector, link state, and path vector routing protocols.',
          difficulty: 'Hard',
          estimatedTime: '20-25 minutes'
        },
        {
          id: '15',
          title: 'Network Security',
          description: 'Encryption, authentication, firewalls, and common security threats.',
          difficulty: 'Medium',
          estimatedTime: '15-20 minutes'
        },
        {
          id: '16',
          title: 'HTTP and Web Technologies',
          description: 'HTTP protocol, REST APIs, and web application architectures.',
          difficulty: 'Easy',
          estimatedTime: '12-15 minutes'
        }
      ]
    }
  ];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800 border-green-300';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'Hard': return 'bg-red-100 text-red-800 border-red-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center space-x-2">
            <Book className="w-6 h-6" />
            <span>Presentation Topics</span>
          </CardTitle>
          <CardDescription>
            Browse and view all available presentation topics for each subject
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue={subjects[0].code} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          {subjects.map((subject) => (
            <TabsTrigger key={subject.code} value={subject.code}>
              {subject.code}
            </TabsTrigger>
          ))}
        </TabsList>

        {subjects.map((subject) => (
          <TabsContent key={subject.code} value={subject.code}>
            <Card>
              <CardHeader>
                <CardTitle>{subject.name}</CardTitle>
                <CardDescription>
                  Course Code: {subject.code} • {subject.topics.length} topics available
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {subject.topics.map((topic) => (
                    <div
                      key={topic.id}
                      className="p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="font-medium text-lg">{topic.title}</h3>
                        <div className="flex space-x-2">
                          <Badge
                            variant="outline"
                            className={getDifficultyColor(topic.difficulty)}
                          >
                            {topic.difficulty}
                          </Badge>
                          {topic.assignedTo && (
                            <Badge variant="secondary">
                              <Users className="w-3 h-3 mr-1" />
                              Assigned
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-muted-foreground mb-3">
                        {topic.description}
                      </p>
                      
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-4">
                          <span className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>{topic.estimatedTime}</span>
                          </span>
                          {topic.assignedTo && (
                            <span className="flex items-center space-x-1">
                              <Users className="w-4 h-4" />
                              <span>{topic.assignedTo}</span>
                            </span>
                          )}
                        </div>
                        {topic.dueDate && (
                          <span className="flex items-center space-x-1 text-orange-600">
                            <Calendar className="w-4 h-4" />
                            <span>Due: {formatDate(topic.dueDate)}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}