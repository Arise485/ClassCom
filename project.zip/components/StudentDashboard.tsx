import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar, ExternalLink, CheckCircle, Clock } from 'lucide-react';

interface Student {
  rollNumber: string;
  name: string;
  isAdmin: boolean;
}

interface Presentation {
  id: string;
  subject: string;
  topic: string;
  dueDate: string;
  formLink: string;
  status: 'pending' | 'submitted';
  submittedDate?: string;
}

interface StudentDashboardProps {
  student: Student;
  presentations: Presentation[];
}

export function StudentDashboard({ student, presentations }: StudentDashboardProps) {
  const upcomingPresentations = presentations.filter(p => p.status === 'pending');
  const completedPresentations = presentations.filter(p => p.status === 'submitted');

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date();
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Welcome Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl md:text-2xl">Welcome back, {student.name}!</CardTitle>
          <CardDescription className="flex flex-col space-y-2 md:flex-row md:items-center md:space-y-0">
            <span>Roll Number: {student.rollNumber}</span>
            {student.isAdmin && (
              <Badge variant="secondary" className="self-start md:ml-2">Class Representative</Badge>
            )}
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Upcoming Presentations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="w-5 h-5" />
            <span>Upcoming Presentations</span>
          </CardTitle>
          <CardDescription>
            Presentations you need to submit
          </CardDescription>
        </CardHeader>
        <CardContent>
          {upcomingPresentations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
              <p>No upcoming presentations. Great job!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingPresentations.map((presentation) => (
                <div
                  key={presentation.id}
                  className={`p-4 border rounded-lg ${
                    isOverdue(presentation.dueDate) 
                      ? 'border-destructive bg-destructive/5' 
                      : 'border-border'
                  }`}
                >
                  <div className="flex flex-col space-y-3 md:flex-row md:justify-between md:items-start md:space-y-0">
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-col space-y-1 md:flex-row md:items-center md:space-y-0 md:space-x-2">
                        <h3 className="font-medium">{presentation.subject}</h3>
                        {isOverdue(presentation.dueDate) && (
                          <Badge variant="destructive" className="self-start">Overdue</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{presentation.topic}</p>
                      <div className="flex items-center space-x-2 text-sm">
                        <Calendar className="w-4 h-4" />
                        <span>Due: {formatDate(presentation.dueDate)}</span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => window.open(presentation.formLink, '_blank')}
                      className="flex items-center justify-center space-x-2 w-full md:w-auto md:ml-4"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Submit PPT</span>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Completed Tasks */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span>Completed Presentations</span>
          </CardTitle>
          <CardDescription>
            Presentations you have successfully submitted
          </CardDescription>
        </CardHeader>
        <CardContent>
          {completedPresentations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No completed presentations yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {completedPresentations.map((presentation) => (
                <div
                  key={presentation.id}
                  className="p-4 border rounded-lg bg-green-50 border-green-200"
                >
                  <div className="space-y-2">
                    <div className="flex flex-col space-y-1 md:flex-row md:items-center md:space-y-0 md:space-x-2">
                      <h3 className="font-medium">{presentation.subject}</h3>
                      <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300 self-start">
                        Submitted
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{presentation.topic}</p>
                    <div className="flex flex-col space-y-2 text-sm md:flex-row md:items-center md:space-y-0 md:space-x-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4" />
                        <span>Due: {formatDate(presentation.dueDate)}</span>
                      </div>
                      {presentation.submittedDate && (
                        <div className="flex items-center space-x-2 text-green-600">
                          <CheckCircle className="w-4 h-4" />
                          <span>Submitted: {formatDate(presentation.submittedDate)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}