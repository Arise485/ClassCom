import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { BookOpen, CheckCircle, Clock, FileText } from 'lucide-react';

interface SyllabusUnit {
  unit: string;
  title: string;
  topics: string[];
  hours: number;
  completed: boolean;
}

interface Subject {
  name: string;
  code: string;
  credits: number;
  instructor: string;
  description: string;
  objectives: string[];
  units: SyllabusUnit[];
  textbooks: string[];
  references: string[];
}

export function SyllabusDashboard() {
  const subjects: Subject[] = [
    {
      name: 'Data Structures',
      code: 'CS301',
      credits: 4,
      instructor: 'Dr. Smith Johnson',
      description: 'This course covers fundamental data structures and their applications in computer science.',
      objectives: [
        'Understand various data structures and their implementations',
        'Analyze time and space complexity of algorithms',
        'Apply appropriate data structures to solve real-world problems',
        'Implement efficient algorithms using various data structures'
      ],
      units: [
        {
          unit: 'Unit 1',
          title: 'Introduction to Data Structures',
          topics: [
            'Abstract Data Types',
            'Arrays and Strings',
            'Complexity Analysis',
            'Big O Notation'
          ],
          hours: 12,
          completed: true
        },
        {
          unit: 'Unit 2',
          title: 'Linear Data Structures',
          topics: [
            'Stacks and Queues',
            'Linked Lists',
            'Applications of Linear Structures',
            'Implementation Techniques'
          ],
          hours: 15,
          completed: true
        },
        {
          unit: 'Unit 3',
          title: 'Trees and Graphs',
          topics: [
            'Binary Trees',
            'Binary Search Trees',
            'Balanced Trees (AVL, Red-Black)',
            'Graph Representations and Traversals'
          ],
          hours: 18,
          completed: false
        },
        {
          unit: 'Unit 4',
          title: 'Advanced Data Structures',
          topics: [
            'Heaps and Priority Queues',
            'Hash Tables',
            'Tries',
            'Disjoint Set Union'
          ],
          hours: 15,
          completed: false
        }
      ],
      textbooks: [
        'Introduction to Algorithms by Cormen, Leiserson, Rivest & Stein',
        'Data Structures and Algorithm Analysis in C++ by Mark Allen Weiss'
      ],
      references: [
        'Algorithms by Robert Sedgewick',
        'Data Structures Using C++ by D.S. Malik'
      ]
    },
    {
      name: 'Operating Systems',
      code: 'CS302',
      credits: 4,
      instructor: 'Prof. Emily Davis',
      description: 'Comprehensive study of operating system concepts, design, and implementation.',
      objectives: [
        'Understand OS structure and components',
        'Learn process and thread management',
        'Master memory and file system management',
        'Analyze system performance and security'
      ],
      units: [
        {
          unit: 'Unit 1',
          title: 'Introduction to Operating Systems',
          topics: [
            'OS Overview and Functions',
            'System Calls and APIs',
            'OS Structure',
            'Virtual Machines'
          ],
          hours: 10,
          completed: true
        },
        {
          unit: 'Unit 2',
          title: 'Process Management',
          topics: [
            'Processes and Threads',
            'CPU Scheduling',
            'Process Synchronization',
            'Deadlocks'
          ],
          hours: 20,
          completed: false
        },
        {
          unit: 'Unit 3',
          title: 'Memory Management',
          topics: [
            'Main Memory Management',
            'Virtual Memory',
            'Paging and Segmentation',
            'Memory Allocation Strategies'
          ],
          hours: 18,
          completed: false
        },
        {
          unit: 'Unit 4',
          title: 'Storage and I/O',
          topics: [
            'File System Interface',
            'File System Implementation',
            'Mass Storage Structure',
            'I/O Systems'
          ],
          hours: 12,
          completed: false
        }
      ],
      textbooks: [
        'Operating System Concepts by Abraham Silberschatz',
        'Modern Operating Systems by Andrew S. Tanenbaum'
      ],
      references: [
        'Operating Systems: Design and Implementation by Tanenbaum',
        'The Design of the UNIX Operating System by Maurice Bach'
      ]
    },
    {
      name: 'Database Systems',
      code: 'CS303',
      credits: 3,
      instructor: 'Dr. Michael Brown',
      description: 'Study of database design, implementation, and management systems.',
      objectives: [
        'Design efficient database schemas',
        'Master SQL and database querying',
        'Understand transaction processing',
        'Learn database administration concepts'
      ],
      units: [
        {
          unit: 'Unit 1',
          title: 'Database Fundamentals',
          topics: [
            'Database Concepts',
            'Data Models',
            'Database Architecture',
            'DBMS Components'
          ],
          hours: 12,
          completed: true
        },
        {
          unit: 'Unit 2',
          title: 'Relational Model and SQL',
          topics: [
            'Relational Model',
            'SQL Fundamentals',
            'Advanced SQL',
            'Views and Indexes'
          ],
          hours: 16,
          completed: true
        },
        {
          unit: 'Unit 3',
          title: 'Database Design',
          topics: [
            'ER Modeling',
            'Normalization',
            'Functional Dependencies',
            'Schema Refinement'
          ],
          hours: 14,
          completed: false
        },
        {
          unit: 'Unit 4',
          title: 'Advanced Topics',
          topics: [
            'Transaction Processing',
            'Concurrency Control',
            'Recovery Systems',
            'Distributed Databases'
          ],
          hours: 12,
          completed: false
        }
      ],
      textbooks: [
        'Database System Concepts by Silberschatz, Korth & Sudarshan',
        'Fundamentals of Database Systems by Elmasri & Navathe'
      ],
      references: [
        'Database Management Systems by Raghu Ramakrishnan',
        'Database Systems: The Complete Book by Garcia-Molina'
      ]
    },
    {
      name: 'Computer Networks',
      code: 'CS304',
      credits: 3,
      instructor: 'Prof. Sarah Wilson',
      description: 'Comprehensive study of computer networking principles and protocols.',
      objectives: [
        'Understand network architectures and protocols',
        'Learn about different network layers',
        'Master routing and switching concepts',
        'Analyze network security and performance'
      ],
      units: [
        {
          unit: 'Unit 1',
          title: 'Network Fundamentals',
          topics: [
            'Network Types and Topologies',
            'OSI and TCP/IP Models',
            'Network Hardware',
            'Protocol Basics'
          ],
          hours: 10,
          completed: true
        },
        {
          unit: 'Unit 2',
          title: 'Physical and Data Link Layer',
          topics: [
            'Transmission Media',
            'Error Detection and Correction',
            'Flow Control',
            'Multiple Access Protocols'
          ],
          hours: 12,
          completed: false
        },
        {
          unit: 'Unit 3',
          title: 'Network and Transport Layer',
          topics: [
            'IP Protocol',
            'Routing Algorithms',
            'TCP and UDP',
            'Congestion Control'
          ],
          hours: 16,
          completed: false
        },
        {
          unit: 'Unit 4',
          title: 'Application Layer and Security',
          topics: [
            'HTTP and Web',
            'Email and DNS',
            'Network Security',
            'Cryptography Basics'
          ],
          hours: 12,
          completed: false
        }
      ],
      textbooks: [
        'Computer Networking: A Top-Down Approach by Kurose & Ross',
        'Computer Networks by Andrew S. Tanenbaum'
      ],
      references: [
        'TCP/IP Illustrated by W. Richard Stevens',
        'Network Security Essentials by William Stallings'
      ]
    }
  ];

  const calculateProgress = (units: SyllabusUnit[]) => {
    const completedUnits = units.filter(unit => unit.completed).length;
    return (completedUnits / units.length) * 100;
  };

  const getTotalHours = (units: SyllabusUnit[]) => {
    return units.reduce((total, unit) => total + unit.hours, 0);
  };

  const getCompletedHours = (units: SyllabusUnit[]) => {
    return units.filter(unit => unit.completed).reduce((total, unit) => total + unit.hours, 0);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center space-x-2">
            <BookOpen className="w-6 h-6" />
            <span>Course Syllabus</span>
          </CardTitle>
          <CardDescription>
            Detailed syllabus for all subjects including course objectives, units, and references
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue={subjects[0].code} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          {subjects.map((subject) => (
            <TabsTrigger key={subject.code} value={subject.code}>
              {subject.code}
            </TabsTrigger>
          ))}
        </TabsList>

        {subjects.map((subject) => (
          <TabsContent key={subject.code} value={subject.code}>
            <div className="space-y-6">
              {/* Course Overview */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{subject.name}</CardTitle>
                      <CardDescription>
                        {subject.code} • {subject.credits} Credits • {subject.instructor}
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-muted-foreground mb-2">Course Progress</div>
                      <div className="flex items-center space-x-2">
                        <Progress value={calculateProgress(subject.units)} className="w-24" />
                        <span className="text-sm font-medium">
                          {Math.round(calculateProgress(subject.units))}%
                        </span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Course Description</h4>
                      <p className="text-muted-foreground">{subject.description}</p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Learning Objectives</h4>
                      <ul className="space-y-1">
                        {subject.objectives.map((objective, index) => (
                          <li key={index} className="flex items-start space-x-2 text-muted-foreground">
                            <span className="text-primary">•</span>
                            <span>{objective}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">
                          {getCompletedHours(subject.units)}/{getTotalHours(subject.units)} hours
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span className="text-sm">
                          {subject.units.filter(u => u.completed).length}/{subject.units.length} units completed
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <FileText className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{subject.credits} credits</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Course Units */}
              <Card>
                <CardHeader>
                  <CardTitle>Course Units</CardTitle>
                  <CardDescription>Detailed breakdown of course content by units</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {subject.units.map((unit, index) => (
                      <div
                        key={index}
                        className={`p-4 border rounded-lg ${
                          unit.completed ? 'bg-green-50 border-green-200' : 'bg-muted/20'
                        }`}
                      >
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h4 className="font-medium flex items-center space-x-2">
                              <span>{unit.unit}: {unit.title}</span>
                              {unit.completed && (
                                <CheckCircle className="w-4 h-4 text-green-600" />
                              )}
                            </h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              {unit.hours} hours
                            </p>
                          </div>
                          <Badge
                            variant={unit.completed ? 'default' : 'secondary'}
                            className={unit.completed ? 'bg-green-100 text-green-800 border-green-300' : ''}
                          >
                            {unit.completed ? 'Completed' : 'Upcoming'}
                          </Badge>
                        </div>
                        
                        <div>
                          <h5 className="text-sm font-medium mb-2">Topics Covered:</h5>
                          <ul className="grid grid-cols-1 md:grid-cols-2 gap-1">
                            {unit.topics.map((topic, topicIndex) => (
                              <li key={topicIndex} className="flex items-start space-x-2 text-sm text-muted-foreground">
                                <span className="text-primary">•</span>
                                <span>{topic}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* References */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Textbooks</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {subject.textbooks.map((book, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <BookOpen className="w-4 h-4 mt-0.5 text-primary" />
                          <span className="text-sm">{book}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>References</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {subject.references.map((ref, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <FileText className="w-4 h-4 mt-0.5 text-muted-foreground" />
                          <span className="text-sm">{ref}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}