import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { Users, AlertTriangle, Send, CheckCircle } from 'lucide-react';

interface Student {
  rollNumber: string;
  name: string;
  isAdmin: boolean;
}

interface Presentation {
  id: string;
  subject: string;
  topic: string;
  dueDate: string;
  formLink: string;
  status: 'pending' | 'submitted';
  submittedDate?: string;
}

interface AdminDashboardProps {
  students: Student[];
  presentations: Presentation[];
}

export function AdminDashboard({ students, presentations }: AdminDashboardProps) {
  const [selectedStudent, setSelectedStudent] = useState('');
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSubject, setAlertSubject] = useState('');
  const [alertSent, setAlertSent] = useState(false);

  const regularStudents = students.filter(s => !s.isAdmin);
  const pendingPresentations = presentations.filter(p => p.status === 'pending');
  
  const getStudentStatus = (rollNumber: string) => {
    const studentPresentations = presentations.filter(p => p.status === 'pending');
    const overdueCount = studentPresentations.filter(p => new Date(p.dueDate) < new Date()).length;
    const pendingCount = studentPresentations.length;
    
    return { overdueCount, pendingCount };
  };

  const handleSendAlert = () => {
    if (!selectedStudent || !alertMessage) {
      return;
    }

    // In a real app, this would send the alert via email/notification
    setAlertSent(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setAlertSent(false);
      setSelectedStudent('');
      setAlertMessage('');
      setAlertSubject('');
    }, 3000);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Admin Header */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl md:text-2xl flex items-center space-x-2">
            <Users className="w-5 h-5 md:w-6 md:h-6" />
            <span>Administrator Dashboard</span>
          </CardTitle>
          <CardDescription>
            Manage class presentations and send alerts to students
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Student Status Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Class Status Overview</CardTitle>
            <CardDescription>Current status of all students</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {regularStudents.map((student) => {
                const status = getStudentStatus(student.rollNumber);
                return (
                  <div
                    key={student.rollNumber}
                    className="flex flex-col space-y-3 p-3 border rounded-lg md:flex-row md:justify-between md:items-center md:space-y-0"
                  >
                    <div>
                      <h4 className="font-medium">{student.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        Roll: {student.rollNumber}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {status.overdueCount > 0 && (
                        <Badge variant="destructive">
                          {status.overdueCount} Overdue
                        </Badge>
                      )}
                      {status.pendingCount > 0 && (
                        <Badge variant="secondary">
                          {status.pendingCount} Pending
                        </Badge>
                      )}
                      {status.pendingCount === 0 && (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Up to date
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Send Alert */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5" />
              <span>Send Alert</span>
            </CardTitle>
            <CardDescription>
              Send reminders or alerts to specific students
            </CardDescription>
          </CardHeader>
          <CardContent>
            {alertSent ? (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Alert sent successfully!
                </AlertDescription>
              </Alert>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="student-select">Select Student</Label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a student" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Students</SelectItem>
                      {regularStudents.map((student) => (
                        <SelectItem key={student.rollNumber} value={student.rollNumber}>
                          {student.name} ({student.rollNumber})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="alert-subject">Subject</Label>
                  <Input
                    id="alert-subject"
                    placeholder="e.g., Presentation Reminder"
                    value={alertSubject}
                    onChange={(e) => setAlertSubject(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="alert-message">Message</Label>
                  <Textarea
                    id="alert-message"
                    placeholder="Enter your alert message here..."
                    value={alertMessage}
                    onChange={(e) => setAlertMessage(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button 
                  onClick={handleSendAlert}
                  disabled={!selectedStudent || !alertMessage}
                  className="w-full flex items-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Alert</span>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Pending Presentations Overview */}
      <Card>
        <CardHeader>
          <CardTitle>All Pending Presentations</CardTitle>
          <CardDescription>Overview of all upcoming presentations</CardDescription>
        </CardHeader>
        <CardContent>
          {pendingPresentations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
              <p>No pending presentations!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingPresentations.map((presentation) => {
                const isOverdue = new Date(presentation.dueDate) < new Date();
                return (
                  <div
                    key={presentation.id}
                    className={`p-4 border rounded-lg ${
                      isOverdue ? 'border-destructive bg-destructive/5' : 'border-border'
                    }`}
                  >
                    <div className="flex flex-col space-y-3 md:flex-row md:justify-between md:items-start md:space-y-0">
                      <div className="flex-1">
                        <div className="flex flex-col space-y-1 mb-2 md:flex-row md:items-center md:space-y-0 md:space-x-2">
                          <h4 className="font-medium">{presentation.subject}</h4>
                          {isOverdue && <Badge variant="destructive" className="self-start">Overdue</Badge>}
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">
                          {presentation.topic}
                        </p>
                        <p className="text-sm">
                          Due: {formatDate(presentation.dueDate)}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(presentation.formLink, '_blank')}
                        className="w-full md:w-auto md:ml-4"
                      >
                        View Form
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}