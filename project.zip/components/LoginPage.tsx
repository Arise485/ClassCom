import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { GraduationCap } from 'lucide-react';

interface Student {
  rollNumber: string;
  name: string;
  isAdmin: boolean;
}

interface LoginPageProps {
  students: Student[];
  onLogin: (student: Student) => void;
}

export function LoginPage({ students, onLogin }: LoginPageProps) {
  const [rollNumber, setRollNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPasswordField, setShowPasswordField] = useState(false);
  const [error, setError] = useState('');
  const [pendingStudent, setPendingStudent] = useState<Student | null>(null);

  const handleRollNumberSubmit = () => {
    const student = students.find(s => s.rollNumber === rollNumber);
    
    if (!student) {
      setError('Invalid roll number. Please try again.');
      return;
    }

    if (student.isAdmin) {
      setPendingStudent(student);
      setShowPasswordField(true);
      setError('');
    } else {
      onLogin(student);
    }
  };

  const handlePasswordSubmit = () => {
    if (password === 'admin123') { // Simple password for demo
      if (pendingStudent) {
        onLogin(pendingStudent);
      }
    } else {
      setError('Invalid admin password. Please try again.');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (showPasswordField) {
        handlePasswordSubmit();
      } else {
        handleRollNumberSubmit();
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-primary/10 rounded-full">
              <GraduationCap className="w-8 h-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl">Student Portal</CardTitle>
          <CardDescription>
            Enter your roll number to access the portal
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="rollNumber">Roll Number</Label>
            <Input
              id="rollNumber"
              type="text"
              placeholder="Enter your roll number"
              value={rollNumber}
              onChange={(e) => setRollNumber(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={showPasswordField}
            />
          </div>

          {showPasswordField && (
            <div className="space-y-2">
              <Label htmlFor="password">Admin Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter admin password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyPress={handleKeyPress}
              />
              <p className="text-sm text-muted-foreground">
                Admin access detected for {pendingStudent?.name}
              </p>
            </div>
          )}

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Button 
            className="w-full" 
            onClick={showPasswordField ? handlePasswordSubmit : handleRollNumberSubmit}
          >
            {showPasswordField ? 'Login as Admin' : 'Continue'}
          </Button>

          {showPasswordField && (
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => {
                setShowPasswordField(false);
                setPendingStudent(null);
                setPassword('');
                setError('');
              }}
            >
              Back to Roll Number
            </Button>
          )}

          <div className="text-sm text-muted-foreground text-center mt-6">
            <p>Demo credentials:</p>
            <p>Students: 101, 102, 103, 104</p>
            <p>Admin: CR001 (password: admin123)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}