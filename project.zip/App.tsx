import React, { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { StudentDashboard } from './components/StudentDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { PPTTopicsDashboard } from './components/PPTTopicsDashboard';
import { SyllabusDashboard } from './components/SyllabusDashboard';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { User, BookOpen, Presentation, LogOut } from 'lucide-react';

interface Student {
  rollNumber: string;
  name: string;
  isAdmin: boolean;
}

interface Presentation {
  id: string;
  subject: string;
  topic: string;
  dueDate: string;
  formLink: string;
  status: 'pending' | 'submitted';
  submittedDate?: string;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState<Student | null>(null);
  const [currentView, setCurrentView] = useState<'dashboard' | 'admin' | 'topics' | 'syllabus'>('dashboard');

  // Mock data
  const students = [
    { rollNumber: 'CR001', name: 'Alex Johnson', isAdmin: true },
    { rollNumber: '101', name: 'Sarah Wilson', isAdmin: false },
    { rollNumber: '102', name: 'Mike Chen', isAdmin: false },
    { rollNumber: '103', name: 'Emma Davis', isAdmin: false },
    { rollNumber: '104', name: 'Raj Patel', isAdmin: false },
  ];

  const presentations: Presentation[] = [
    {
      id: '1',
      subject: 'Data Structures',
      topic: 'Binary Search Trees',
      dueDate: '2024-01-25',
      formLink: 'https://forms.google.com/example1',
      status: 'pending'
    },
    {
      id: '2',
      subject: 'Operating Systems',
      topic: 'Process Scheduling',
      dueDate: '2024-01-28',
      formLink: 'https://forms.google.com/example2',
      status: 'pending'
    },
    {
      id: '3',
      subject: 'Database Systems',
      topic: 'SQL Joins',
      dueDate: '2024-01-15',
      formLink: 'https://forms.google.com/example3',
      status: 'submitted',
      submittedDate: '2024-01-14'
    }
  ];

  const handleLogin = (student: Student) => {
    setCurrentUser(student);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('dashboard');
  };

  if (!currentUser) {
    return <LoginPage students={students} onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <div className="border-b bg-white sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Desktop Header */}
          <div className="hidden md:flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-semibold">Student Portal</h1>
              <span className="text-sm text-muted-foreground">
                Welcome, {currentUser.name}
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <nav className="flex space-x-2">
                <Button
                  variant={currentView === 'dashboard' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('dashboard')}
                  className="flex items-center space-x-2"
                >
                  <User className="w-4 h-4" />
                  <span>Dashboard</span>
                </Button>
                
                <Button
                  variant={currentView === 'topics' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('topics')}
                  className="flex items-center space-x-2"
                >
                  <Presentation className="w-4 h-4" />
                  <span>PPT Topics</span>
                </Button>
                
                <Button
                  variant={currentView === 'syllabus' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('syllabus')}
                  className="flex items-center space-x-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Syllabus</span>
                </Button>
                
                {currentUser.isAdmin && (
                  <Button
                    variant={currentView === 'admin' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setCurrentView('admin')}
                    className="flex items-center space-x-2"
                  >
                    <span>Admin</span>
                  </Button>
                )}
              </nav>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center space-x-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </Button>
            </div>
          </div>

          {/* Mobile Header */}
          <div className="md:hidden">
            {/* Top row with title and logout */}
            <div className="flex justify-between items-center h-14 border-b border-border/50">
              <div className="flex flex-col">
                <h1 className="text-lg font-semibold">Student Portal</h1>
                <span className="text-xs text-muted-foreground">
                  {currentUser.name}
                </span>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="flex items-center space-x-1 px-3"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-xs">Logout</span>
              </Button>
            </div>

            {/* Bottom row with navigation */}
            <div className="py-3">
              <nav className="grid grid-cols-3 gap-2">
                <Button
                  variant={currentView === 'dashboard' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('dashboard')}
                  className="flex flex-col items-center space-y-1 h-auto py-2 px-2"
                >
                  <User className="w-4 h-4" />
                  <span className="text-xs">Dashboard</span>
                </Button>
                
                <Button
                  variant={currentView === 'topics' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('topics')}
                  className="flex flex-col items-center space-y-1 h-auto py-2 px-2"
                >
                  <Presentation className="w-4 h-4" />
                  <span className="text-xs">Topics</span>
                </Button>
                
                <Button
                  variant={currentView === 'syllabus' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentView('syllabus')}
                  className="flex flex-col items-center space-y-1 h-auto py-2 px-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span className="text-xs">Syllabus</span>
                </Button>
              </nav>
              
              {/* Admin button on mobile - full width when available */}
              {currentUser.isAdmin && (
                <Button
                  variant={currentView === 'admin' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCurrentView('admin')}
                  className="w-full mt-2 flex items-center justify-center space-x-2"
                >
                  <span>Administrator Panel</span>
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 md:py-8">
        {currentView === 'dashboard' && (
          <StudentDashboard 
            student={currentUser} 
            presentations={presentations}
          />
        )}
        
        {currentView === 'admin' && currentUser.isAdmin && (
          <AdminDashboard 
            students={students}
            presentations={presentations}
          />
        )}
        
        {currentView === 'topics' && (
          <PPTTopicsDashboard />
        )}
        
        {currentView === 'syllabus' && (
          <SyllabusDashboard />
        )}
      </div>
    </div>
  );
}